package com.example.cs360week3_3_meganmitchell;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360week3_3_meganmitchell.db.DatabaseHelper;

import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView recyclerData;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // 1) Database
        db = new DatabaseHelper(this);
        db.getWritableDatabase();

        // 2) RecyclerView setup
        recyclerData = findViewById(R.id.recyclerData);
        recyclerData.setLayoutManager(new LinearLayoutManager(this));

        items = new ArrayList<>();

        adapter = new InventoryAdapter(
                items,
                item -> { // DELETE
                    int deleted = db.deleteInventoryItem(item.id);
                    if (deleted > 0) {
                        Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show();
                        loadItemsFromDb();
                    } else {
                        Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                    }
                },
                item -> { // EDIT (tap row)
                    showEditItemDialog(item);
                }
        );

        recyclerData.setAdapter(adapter);

        // 3) Load existing items from DB
        loadItemsFromDb();

        // 4) Add Item button
        findViewById(R.id.btnAddItem).setOnClickListener(v -> showAddItemDialog());
    }

    private void loadItemsFromDb() {
        items.clear();

        Cursor cursor = db.getAllInventoryItems();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QTY));

                items.add(new InventoryItem(id, name, qty));
            }
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }

    private void showAddItemDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);

        EditText editName = dialogView.findViewById(R.id.dialogItemName);
        EditText editQty = dialogView.findViewById(R.id.dialogItemQty);

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = editName.getText().toString().trim();
                    String qtyText = editQty.getText().toString().trim();

                    if (name.isEmpty() || qtyText.isEmpty()) {
                        Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty;
                    try {
                        qty = Integer.parseInt(qtyText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long result = db.addInventoryItem(name, qty);
                    if (result != -1) {
                        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                        loadItemsFromDb();
                    } else {
                        Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ADDED: EDIT/UPDATE dialog
    private void showEditItemDialog(InventoryItem item) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);

        EditText editName = dialogView.findViewById(R.id.dialogItemName);
        EditText editQty = dialogView.findViewById(R.id.dialogItemQty);

        // Pre-fill current values
        editName.setText(item.name);
        editQty.setText(String.valueOf(item.quantity));

        new AlertDialog.Builder(this)
                .setTitle("Edit Item")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newName = editName.getText().toString().trim();
                    String qtyText = editQty.getText().toString().trim();

                    if (newName.isEmpty() || qtyText.isEmpty()) {
                        Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int newQty;
                    try {
                        newQty = Integer.parseInt(qtyText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int updated = db.updateInventoryItem(item.id, newName, newQty);
                    if (updated > 0) {
                        Toast.makeText(this, "Updated!", Toast.LENGTH_SHORT).show();
                        loadItemsFromDb();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
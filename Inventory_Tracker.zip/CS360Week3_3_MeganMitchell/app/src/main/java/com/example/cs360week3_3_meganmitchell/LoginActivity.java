package com.example.cs360week3_3_meganmitchell;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.example.cs360week3_3_meganmitchell.db.DatabaseHelper;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        DatabaseHelper db = new DatabaseHelper(this);
        db.getWritableDatabase();

        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.validateLogin(username, password)) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
            } else {
                Toast.makeText(this, "Invalid login. Try again.", Toast.LENGTH_SHORT).show();
            }
        });



        btnCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password first", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.userExists(username)) {
                Toast.makeText(this, "Username already exists. Pick another.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = db.registerUser(username, password);
            if (created) {
                Toast.makeText(this, "Account created! Now log in.", Toast.LENGTH_SHORT).show();
                editPassword.setText("");
            } else {
                Toast.makeText(this, "Account creation failed.", Toast.LENGTH_SHORT).show();
            }
        });

    }
}

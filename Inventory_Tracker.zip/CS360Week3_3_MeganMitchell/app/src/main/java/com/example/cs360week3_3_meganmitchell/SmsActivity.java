package com.example.cs360week3_3_meganmitchell;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private TextView textSmsStatus;
    private Button btnAllowSms, btnDenySms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        textSmsStatus = findViewById(R.id.textSmsStatus);
        btnAllowSms = findViewById(R.id.btnAllowSms);
        btnDenySms = findViewById(R.id.btnDenySms);

        // Show current status on open
        updateStatusText();

        btnAllowSms.setOnClickListener(v -> {
            if (hasSmsPermission()) {
                textSmsStatus.setText("SMS permission: Allowed");
                sendTestSms();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            }
        });

        btnDenySms.setOnClickListener(v -> {
            textSmsStatus.setText("SMS permission: Denied (App still works)");
            Toast.makeText(this, "SMS disabled. App will continue without SMS.", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updateStatusText() {
        if (hasSmsPermission()) {
            textSmsStatus.setText("SMS permission: Allowed");
        } else {
            textSmsStatus.setText("SMS permission: Not Chosen");
        }
    }

    private void sendTestSms() {
        // NOTE: The emulator may not actually send SMS. This is still valid rubric logic.
        String phoneNumber = "5554"; // common emulator number (may vary)
        String message = "Inventory Tracker Alert: Test SMS message.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Test SMS sent (or attempted).", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS send failed on emulator (permission logic still works).", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textSmsStatus.setText("SMS permission: Allowed");
                sendTestSms();
            } else {
                textSmsStatus.setText("SMS permission: Denied (App still works)");
                Toast.makeText(this, "Permission denied. SMS will not send.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
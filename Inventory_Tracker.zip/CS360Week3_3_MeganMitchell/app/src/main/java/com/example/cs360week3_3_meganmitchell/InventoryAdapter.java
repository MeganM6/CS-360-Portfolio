package com.example.cs360week3_3_meganmitchell;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    // DELETE listener
    public interface OnDeleteClickListener {
        void onDeleteClick(InventoryItem item);
    }

    // ADD: ITEM CLICK listener (for EDIT/UPDATE)
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    private final ArrayList<InventoryItem> items;
    private final OnDeleteClickListener deleteListener;

    // ADD: field for item click listener
    private final OnItemClickListener itemClickListener;

    // CHANGE: constructor now takes BOTH listeners
    public InventoryAdapter(ArrayList<InventoryItem> items,
                            OnDeleteClickListener deleteListener,
                            OnItemClickListener itemClickListener) {
        this.items = items;
        this.deleteListener = deleteListener;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.textItemName.setText(item.name);
        holder.textItemQty.setText(String.valueOf(item.quantity));

        // Delete button
        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(item);
            }
        });

        // ADD: tap row to EDIT
        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName, textItemQty;
        Button btnDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textItemQty = itemView.findViewById(R.id.textItemQty);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}